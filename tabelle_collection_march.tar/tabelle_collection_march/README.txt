The tables called "table_XXX" are text files corresponding more or less to what is already in our paper.
The XXX number does not stay for the corresponding number of the table in the paper, but is my internal notation.

Each file correspond actually to two tables of our paper, because it contains both the bins for the asymmetric bin configuration, and the symmetric bins centered around 342.5 GeV.

At the beginning of each table there is the explanation of the content, so that one can uniquely identify it. 

Please ignore the last two columns, they are there for my cross-checks only.

Please also ignore the lines where is written 'ALLARME', if any appears.

The lines with the numerical values are already formatted according to latex,
so one can copy these lines into the overleaf,
while the other lines are not.

###########################################################################

The tables called "tableunc_XXX" are new, and have the splitting of the
combined uncertainties in components. This has been done for all
NRQCD configurations and all bins.

They contain the combined uncertainties, and the uncertainties due
to various factors (mur, mus, alphas, pdf, Gammat) in decreasing order
of importance.

All uncertainties are in the format + XXX - YYY

They are in pb. 

The lines with the numerical values are already formatted according to latex,
so one can copy these lines into the overleaf,
while the other lines are not.
##############################################################################
